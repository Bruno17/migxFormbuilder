<?php
require_once (dirname(dirname(__FILE__)) . '/mfbform.class.php');
class mfbForm_mysql extends mfbForm {}