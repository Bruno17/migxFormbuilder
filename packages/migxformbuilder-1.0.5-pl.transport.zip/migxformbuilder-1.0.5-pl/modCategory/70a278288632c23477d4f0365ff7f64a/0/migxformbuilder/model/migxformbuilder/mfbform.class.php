<?php
class mfbForm extends xPDOSimpleObject {}