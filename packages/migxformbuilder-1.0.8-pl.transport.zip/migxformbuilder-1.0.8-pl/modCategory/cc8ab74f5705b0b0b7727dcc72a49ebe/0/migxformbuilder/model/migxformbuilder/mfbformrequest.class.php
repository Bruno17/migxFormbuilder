<?php
class mfbFormRequest extends xPDOSimpleObject {}