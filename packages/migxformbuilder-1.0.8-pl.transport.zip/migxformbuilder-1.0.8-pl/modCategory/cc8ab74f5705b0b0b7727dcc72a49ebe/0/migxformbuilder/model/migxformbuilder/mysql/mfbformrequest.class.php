<?php
require_once (dirname(dirname(__FILE__)) . '/mfbformrequest.class.php');
class mfbFormRequest_mysql extends mfbFormRequest {}